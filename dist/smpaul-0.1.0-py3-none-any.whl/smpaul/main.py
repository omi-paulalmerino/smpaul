def greet(nickname: str):
  return f"Hello {nickname}!"